package POO;

import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.Timer;
import java.awt.Toolkit;

public class Temporizador2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	
	Reloj mireloj=new Reloj(3000,true);
	
	mireloj.enMarcha();
	
	JOptionPane.showMessageDialog(null, "Pulsa Aceptar para detener");
	
	}

}


class Reloj{
	
	private int intervalo;
	
	private boolean sonido;
	
	private class DameLaHora implements ActionListener{
		
		public void actionPerformed(ActionEvent evento) {
		
		Date ahora=new Date();
		
		System.out.println("Te pongo la hora cada 3 seg " + ahora);
		
		if(sonido) {
			
			Toolkit.getDefaultToolkit().beep();
		}
		
		
	}
		
	}
	
	public Reloj(int intervalo, boolean sonido) {
		
	this.intervalo=intervalo;
	
	this.sonido=sonido;
	
	}
	
	public void enMarcha() {
		
		ActionListener oyente=new DameLaHora();
		
		Timer mitemporizador=new Timer(intervalo, oyente);

		mitemporizador.start();
	}
}
