package POO.EJEMPLO_COCHE;

/* extends, significa q hereda los datos de coche
   Coche(Superclase) Furgoneta(Subclase)
   JAVA NO PERMITE HERENCIA MULTIPLE
*/
public class Furgoneta extends Coche{

	private int capacidad_carga;
	private int plazas_extra;
		
	public Furgoneta (int plazas_extra, int capacidad_carga) {
		
		super(); //llama al contructor de la clase padre
	
		this.capacidad_carga=capacidad_carga;
		
		this.plazas_extra=plazas_extra;
	
	
	}
	
	
	public String DatosFurgi() {
		
		return "La capacidad de carga es:" + capacidad_carga+ " Y las plazas son:"
				+ plazas_extra;
	}
	
	

}
