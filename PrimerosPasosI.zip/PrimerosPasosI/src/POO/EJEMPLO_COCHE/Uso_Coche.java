package POO.EJEMPLO_COCHE;
 import javax.swing.*;
public class Uso_Coche {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* GETTER
		Coche Renault=new Coche(); //CREAMOS UNA CLASE -- INSTANCIAR UNA CLASE
	
		System.out.println(Renault.dime_largo());
	
	
		 * EJEMPLO DE INSTANCIAR UNA CLASE
		 
		 * FUERA DE LA CLASE
			
		Coche Seat=new Coche();
		System.out.println("Este coche tiene " + Seat.rueda + " ruedas");
		 */
		
		Coche micoche=new Coche();
		
		micoche.establece_color(JOptionPane.showInputDialog("Introduce color"));
		
		System.out.println(micoche.dime_color());

		System.out.println(micoche.dime_datos_generales());

		micoche.configura_asientos(JOptionPane.showInputDialog("�Tiene asientos"));
		
		System.out.println(micoche.asientos());
		
		micoche.configura_climatizador(JOptionPane.showInputDialog("�Tiene climatizador"));
		
		System.out.println(micoche.dime_climatizador());
		
		System.out.println(micoche.peso_coche_total());
		
		System.out.println("El precio final del coche es " + micoche.precio_coche());
		
	}

}
