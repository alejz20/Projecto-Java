package POO.EJEMPLO_COCHE;

public class Uso_Vehiculo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	Coche micoche=new Coche();
	
	micoche.establece_color("Rojo");
	
	Furgoneta mifurgoneta =new Furgoneta (2,8);
	
	mifurgoneta.establece_color("Violeta y azul");
	
	mifurgoneta.configura_asientos("si");
	
	mifurgoneta.configura_climatizador("si");
	
	System.out.println(micoche.dime_datos_generales() + " " + micoche.dime_color());
	
	System.out.println(mifurgoneta.dime_datos_generales() +  mifurgoneta.DatosFurgi());
	}

}
