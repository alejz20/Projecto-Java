package ArraysBidimensionales;

public class Ejemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int matrix [][]=new int [4][5];
		
		matrix[0][0]=34;
		matrix[0][1]=45;
		matrix[0][2]=6;
		matrix[0][3]=56;
		matrix[0][4]=49;
		
		matrix[1][0]=23;
		matrix[1][1]=72;
		matrix[1][2]=673;
		matrix[1][3]=57;
		matrix[1][4]=37;
		
		matrix[2][0]=54;
		matrix[2][1]=43;
		matrix[2][2]=87;
		matrix[2][3]=843;
		matrix[2][4]=82;
		
		matrix[3][0]=123;
		matrix[3][1]=68;
		matrix[3][2]=83;
		matrix[3][3]=93;
		matrix[3][4]=36;
		
		
		for (int [] fila:matrix) {
			
			System.out.println();
			
		for(int z :fila) {
				
			System.out.println(z + " ");	
		
		}
			
		}
		
/*		
		for (int i=0;i<4;i++) {
			
			System.out.println();
			
			for(int j=0;j<5;j++) {
				
				System.out.println(matrix[i][j] + " ");
			}
			}
			
*/
	}

}
