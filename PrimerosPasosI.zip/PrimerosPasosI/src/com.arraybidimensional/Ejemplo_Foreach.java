package ArraysBidimensionales;

public class Ejemplo_Foreach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	int [][] matrix= {
			{23,234,24,02,42},
			{34,52,1,3,35},
			{945,38,983,874,83},
			{56,16,19,78,87}
	};
	
	for (int[]fila:matrix) {
		
		System.out.println();
		
		for(int z:fila) {
			
			System.out.println(z + " ");
			
		}
		
	}
		
	}

}
