package Default;

public class Prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int numero;
		int n2 =45;
		
		numero =46;
		
		System.out.println(numero++ +  " , " + n2);
	}

}
