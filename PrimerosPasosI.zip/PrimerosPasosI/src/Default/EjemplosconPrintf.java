package Default;

public class EjemplosconPrintf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int [] arreglo= {1,2,5,9,13};
		
		for(int i=0; i< arreglo.length; i++ ) {
			
			System.out.printf("%d\n", arreglo[i]);
		}
		
		System.out.printf("%-56s" ,8);
	
	
		
	}

}
