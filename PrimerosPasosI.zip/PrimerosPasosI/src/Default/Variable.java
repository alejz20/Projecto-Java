package Default;

public class Variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1� opcion declarar e iniciar en distintas lineas
	int edad;
	edad=25;
	
     	//2� opcion declarar e iniciar en la misma linea
	
             /* int edad =25;   */
	
	// �Q pasa si iniciamos si declaramos e iniciamos otra variable desdpues de declara una?
	
		/*   int edad;
		 * 
		 *   edad=25;
		 *   
		 *  edad=27;
		 *  
		 *  El resultado en consola seria 27
		 */
	
	System.out.println(edad);
	
	edad=75;
	
	System.out.println(edad);
	
	
	}
}
