package Default;
public class Constantes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double a=5;
		
		double b;
		
		b=7;
		
		double c=b/a;
		
		/*  int c=b-a;
		 * 
		 * int c=b+a;
		 * 
		 * int c=b*a;
		 * 
		 *  */
		
		
		// En el caso de la division saldria un numero entrero, 
		// porque la variable es de tipo int  = entero
		
		/* int c=b/a;
		 * 
		 */
		
		System.out.println(c);
	
	
	
	}

}
