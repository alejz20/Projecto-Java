package Default;

import javax.swing.JOptionPane;
import java.awt.GraphicsEnvironment;

public class FuentesInstaladas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//	System.out.println(nombredeFuente);
		
	String fuente=JOptionPane.showInputDialog("Introduce fuente");
	
	boolean estaLaFuente=false;
	
	String nombredeFuentes[]=GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
	
	for(String nombredeFuente: nombredeFuentes) {
	
	if(nombredeFuente.equals(fuente)) {
		
		estaLaFuente=true;
	}
	
	
	}
	
	if(estaLaFuente) {
		
	System.out.println("Fuente instalada");
		
	} else {
		
		System.out.println("No est� instalada la fuente");
	}
	}

}
