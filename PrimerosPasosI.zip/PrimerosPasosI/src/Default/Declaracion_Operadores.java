package Default;

public class Declaracion_Operadores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Constante
		final double apulgadas=2.54;

		// Variables
		double cm=6;
		
		double resultado=cm/apulgadas;
		
		
		System.out.printf("En " + cm + " cm hay " + resultado + " pulgadas");
		
		/*
		 * int operador1, operador2, resultado;
		 * 
		 * operador1=8;
		 * 
		 * operador2=7;
		 * 
		 * resultado=operador1 + operador2;
		 */
		
	}

}
