package Interfaces;

public interface Trabajadores {

	double establece_bonus(double recompensa);
	
/*	public static final */  double bonus_base=1500;
	
}
