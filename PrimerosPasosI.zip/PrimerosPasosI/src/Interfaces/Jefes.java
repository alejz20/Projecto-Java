package Interfaces;

public interface Jefes extends Trabajadores {

	String tomar_desiciones(String dediciones);
	
	
}
