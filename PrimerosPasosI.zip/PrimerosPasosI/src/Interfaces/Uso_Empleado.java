package Interfaces;

import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;

import Interfaces.Jefes;
import Interfaces.Trabajadores;
public class Uso_Empleado {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Jefatura jefe_RRHH = new Jefatura("Juan", 55000, 2006,9, 25);
		
		jefe_RRHH.estableceIncentivo(2570);
		
		Empleado misEmpleados[] = new Empleado[6];
		
		 misEmpleados[0] = new Empleado ("Alberto Gomez", 85000, 1990, 12, 7);
	
		 misEmpleados[1] = new Empleado ("Ana Lopez", 95000, 1995, 6, 2);
			
		 misEmpleados[2] = new Empleado ("Paco Gomez", 105000, 2002, 3, 15);
		 
		 misEmpleados[3] = new Empleado ("Antonio", 4700 , 2009, 11 , 9);
		
		 misEmpleados[4] = jefe_RRHH; // Polimorfismo en accci�n. Principio de sustituci�n.
		 
		 misEmpleados[5] = new Jefatura ("Mar�a", 95000 , 1999, 5 , 26);
		 
		 Jefatura jefa_Finanzas=(Jefatura) misEmpleados[5]; // CASTING O REFUNDICI�N
		 
		 jefa_Finanzas.estableceIncentivo(5000);
/*
		 Empleado director_comercial = new Jefatura ("Andrea", 85000 , 2002, 5 , 6);

		 Comparable ejemplo = new Empleado ("Eli", 34000 , 1978, 4 ,8);
		 
		 if(director_comercial instanceof Empleado) { //Ejemplo de instanciar un objeto con instanceof
			 
			 System.out.println("Es de tipo jefatura");
		 }
		 
		 if(ejemplo instanceof Comparable) {//Ejemplo de instanciar una interfaz con instanceof
			 
			 System.out.println("Implementa la interfa comparable");
		 }
*/
		 
		 System.out.println(jefa_Finanzas.tomar_desiciones("Dar m�s dias de vacaciones"));
		 
		 System.out.println("El jefe " + jefa_Finanzas.dameNombre() + " tiene un bonus de " + jefa_Finanzas.establece_bonus(500));
		
		 System.out.println(misEmpleados[3].dameNombre() + " tiene un bonus de " + jefa_Finanzas.establece_bonus(200));
			
		 //EJEMPLO CON 'BUCLE For Each'
		 
		for(Empleado e :misEmpleados) {
			
			e.subeSueldo(5);
			
		}
		
		// INTERFAZ sort, al de tipo stattic, ponemos su clase delante:
		Arrays.sort(misEmpleados);
		
		for(Empleado e :misEmpleados) {
			
			System.out.println("Nombre: " + e.dameNombre() 
			+ " Sueldo: " + e.dameSueldo() 
			+ " Fecha de Alta: " + e.dameFechaContrato());
		} 
		
	}

}

//Para usar sort hay que usar la INTERFAZ Comparable

class Empleado implements Comparable, Trabajadores{
	
	private String nombre;   
	private double sueldo;
	private Date altaContrato;
	private int Id;
	public static int IdSiguiente =1;
	
 public Empleado(String nom, double sue, int agno, int mes, int dia){

	
	
	nombre =nom;
	sueldo =sue;
	GregorianCalendar calendario= new GregorianCalendar(agno, mes-1, dia);
	altaContrato=calendario.getTime();
	Id=IdSiguiente;
	IdSiguiente++;
	
}

 	public Empleado(String nom) { // REVISARLO 27/03/22
 		
 		this (nom, 3000, 2000, 01, 01); 
 	}
	public String dameNombre() { //GETTER 
		return nombre + " Id " + Id;
	}
	
	public double dameSueldo() { //GETTER 
		return sueldo;
	}
	
	public Date dameFechaContrato() { //GETTER 
		return altaContrato;
	}
	
	public void subeSueldo(double porcentaje) { //SETTER 
		
		double aumento=sueldo*porcentaje/100;
	
		sueldo+=aumento;
	}

	// Para usar Comparable hay usar su unico metodo compareTo
	public int compareTo(Object miObjeto) {
	
		Empleado otroEmpleado=(Empleado) miObjeto;
		
		if(this.sueldo<otroEmpleado.sueldo) {
			
			return -1;
			
		}
		
		if(this.sueldo>otroEmpleado.sueldo) {
			
			return 1;
			
		}
		
		return 0;
	}
	
	public double establece_bonus(double recompensa) {
		
		return Trabajadores.bonus_base + recompensa;
	}
	
}


class Jefatura extends Empleado implements Jefes {
		
	private double incentivo;
		
		public Jefatura(String nom, double sue, int agno, int mes, int dia ) {
			
			super(nom, sue, agno, mes, dia);
			
		}
		
		public void estableceIncentivo (double b ) {
			
			incentivo=b;
		}
		
		public double dameSueldo(){
			
			double sueldoJefe=super.dameSueldo();
			return sueldoJefe + incentivo;
		}
		
		public String tomar_desiciones(String dediciones) {
			
			return "Un miembro de la direccion ha tomado la dedicion de " + dediciones;
		}
		
		public double establece_bonus(double recompensa) {
			
			double prima=2000;
			
			return Trabajadores.bonus_base + recompensa+prima;
		}
	}
