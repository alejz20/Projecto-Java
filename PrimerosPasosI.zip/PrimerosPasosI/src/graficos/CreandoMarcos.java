package graficos;

import java.awt.Frame;

import javax.swing.*;

public class CreandoMarcos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		miMarco marco1=new miMarco();
		
		marco1.setVisible(true);
		
		marco1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}

class miMarco extends JFrame{
	
	public miMarco() {
		
		setBounds(500,200,500,250); //POSICION Y TAMA�O 
		
	/*	setSize(500,300); // TAMA�O
		
		setLocation(500,250); //POSICION			
		
		setBounds(500,200,500,250); //POSICION Y TAMA�O 	
		
		setResizable(true);		//REDIMENCION LA VENTANA					
		
		setExtendedState(Frame.MAXIMIZED_BOTH);	 //TAMA�O TOTAL
		
		setExtendedState(6); // ES LOMISMO Q EL MAXIMIZED XQ SUS VALORES CONSTANTES					*/
		
		setTitle("Mi ventana favorita");
	}
}
