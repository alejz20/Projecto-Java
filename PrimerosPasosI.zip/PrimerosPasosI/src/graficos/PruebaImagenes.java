package graficos;

import java.awt.Graphics;
import java.awt.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.*;

public class PruebaImagenes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MarcoconImagen mimarco =new MarcoconImagen();
		
		mimarco.setVisible(true);
	
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	
	}

}



class MarcoconImagen extends JFrame {

	public MarcoconImagen() {
		
		setSize(400,400);

		setTitle("Pueba con fuentes");
		
		LaminaconImagen milamina=new LaminaconImagen();
		
		add(milamina); // IMPORTANTE --> MUESTRA MARCO
		

}
	
}


class LaminaconImagen extends JPanel {
	
	private Image imagen;
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		File mimagen= new File("src/graficos/perreo.gif");
		
		try {
			imagen=ImageIO.read(mimagen);
			
		}catch(IOException e) { 
		
		System.out.println("No se encuentra la imagen");
	}
		
		g.drawImage(imagen, 50, 15, null);
	
	}
}