package graficos.Eventos;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PruebaEventos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MarcoconBotones mimarco =new MarcoconBotones();
		
		mimarco.setVisible(true);
	
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	
	
	}

}


class MarcoconBotones extends JFrame {

	public MarcoconBotones() {
		
		setSize(400,400);

		setTitle("Pueba con fuentes");
		
		LaminaBotones milamina=new LaminaBotones();
		
		add(milamina); // IMPORTANTE --> MUESTRA MARCO
		

}
	
}

class LaminaBotones extends JPanel implements ActionListener {
	
	JButton botonAzul=new JButton("Azul");
	
	JButton botonAmarillo=new JButton("Amarillo");
	
	JButton botonRojo=new JButton("Rojo");
	
	public LaminaBotones() {
		
		add(botonAzul);
		
		add(botonAmarillo);
		
		add(botonRojo);
		
		botonAzul.addActionListener(this);
		
		botonAmarillo.addActionListener(this);
		
		botonRojo.addActionListener(this);
	
	}
	
	public void actionPerformed (ActionEvent e) {
		
		Object botonPulsado=e.getSource(); //getSource, es un metodo que dice el origen de la fuente
		
		if (botonPulsado==botonAzul) {
			
			setBackground(Color.BLUE);
		}
		
		else if (botonPulsado==botonAmarillo) {
			
			setBackground(Color.YELLOW);
		}
		
		else if  (botonPulsado==botonRojo) {
			
			setBackground(Color.RED);
		}
	}
}
