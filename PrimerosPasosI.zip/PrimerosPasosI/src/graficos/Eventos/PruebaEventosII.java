package graficos.Eventos;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class PruebaEventosII {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MarcoconBotonesII mimarco =new MarcoconBotonesII();
		
		mimarco.setVisible(true);
	
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	
	
	}

}


class MarcoconBotonesII extends JFrame {

	public MarcoconBotonesII() {
		
		setSize(400,400);

		setTitle("Pueba con fuentesII");
		
		LaminaBotonesII milamina=new LaminaBotonesII();
		
		add(milamina); // IMPORTANTE --> MUESTRA MARCO
		

}
	
}

class LaminaBotonesII extends JPanel  {
	
	JButton botonAzul=new JButton("Azul");
	
	JButton botonAmarillo=new JButton("Amarillo");
	
	JButton botonRojo=new JButton("Rojo");
	
	public LaminaBotonesII() {
		
		add(botonAzul);
		
		add(botonAmarillo);
		
		add(botonRojo);
		
		ColorFondo Amarillo=new ColorFondo(Color.yellow);
		
		ColorFondo Azul=new ColorFondo(Color.blue);
		
		ColorFondo Rojo=new ColorFondo(Color.red);
		
		botonAzul.addActionListener(Azul);
		
		botonAmarillo.addActionListener(Amarillo);
		
		botonRojo.addActionListener(Rojo);
	

	}
	
	private class ColorFondo implements ActionListener {
		
		public ColorFondo(Color c) {
			
			colordeFondo=c;
		}
		
		public void actionPerformed (ActionEvent e) {
			
			setBackground(colordeFondo);
		}
		
	
	private Color colordeFondo;
	
	}
}
