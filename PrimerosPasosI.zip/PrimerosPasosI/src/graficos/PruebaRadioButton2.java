package graficos;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;


public class PruebaRadioButton2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MarcoRadioII marco =new MarcoRadioII();
		 
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

		
		}

	}

	class MarcoRadioII extends JFrame{
		
		public MarcoRadioII() {
			
					
		setBounds(400, 300,550,400);
			
		LaminaRadioII milamina=new LaminaRadioII();
			
		add(milamina);
			
		setVisible(true);
		
		
	}
		
	}

class LaminaRadioII extends JPanel{
	
		private JLabel texto;
		
		private JPanel lamina_botones;
		
		private ButtonGroup migrupo;
		
		private JRadioButton boton1, boton2, boton3, boton4;
		
		public LaminaRadioII() {
			
			setLayout(new BorderLayout());
			
			texto=new JLabel("En lugar de la Mancha de la hostia, creo q no ....");
			
			add(texto,BorderLayout.CENTER);
			
			lamina_botones=new JPanel();
			
			migrupo=new ButtonGroup();
					
			colocarBotones("Peque�o ", false,10);
			
			colocarBotones("Mediano",true, 12);
			
			colocarBotones("Grande ", false, 18);
			
			colocarBotones("Muy Grande",false,26);
			
					
			add(lamina_botones, BorderLayout.SOUTH);
		}
	
		private void colocarBotones(String nombre, boolean seleccionado, final int tamano){

			
			JRadioButton boton=new JRadioButton(nombre, seleccionado);
			
			migrupo.add(boton);
			
			lamina_botones.add(boton);
			
			ActionListener mievento =new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					
				texto.setFont(new Font("Serif", Font.PLAIN, tamano));
					
				}
				};
				
			boton.addActionListener(mievento);
			
			
		}
}	