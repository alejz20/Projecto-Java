package graficos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Varios_oyentes {

	public static void main(String[] args) {
	Marco_Principal marco =new Marco_Principal();
	
	marco.setVisible(true);

	marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}	
}

class Marco_Principal extends JFrame {

	public Marco_Principal() {
		
		
		Lamina_Principal milamina=new Lamina_Principal();
		
		add(milamina); 
	
}
	
}

class Lamina_Principal extends JPanel {

	JButton boton_cerrar;
	
	public Lamina_Principal() {
		
	JButton botonNuevo=new JButton("Nuevo");
	
	add(botonNuevo);

	boton_cerrar=new JButton("Cerrar todo");
	
	add(boton_cerrar);
	
	OyenteNuevo mioyente=new OyenteNuevo();
	
	botonNuevo.addActionListener(mioyente);

	}
	private class OyenteNuevo implements ActionListener{

	
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		Marco_Emergente mimarco =new Marco_Emergente(boton_cerrar);
		
		mimarco.setVisible(true);
	
		
	}

		
}
}

class Marco_Emergente extends JFrame {
	
	private static int contador=0;
	
	public Marco_Emergente(JButton boton_de_principal) {

		contador++;

		setTitle("Ventana " + contador);
		
		setBounds(40*contador,40*contador, 300, 150);
			
		CierraTodos oyenteCerrar=new CierraTodos();
		
		boton_de_principal.addActionListener(oyenteCerrar);
	}

	private class CierraTodos implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		dispose();
		
		}
	}
	
}
