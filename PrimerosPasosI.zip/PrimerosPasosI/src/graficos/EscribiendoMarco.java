package graficos;

import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class EscribiendoMarco {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MaroconTexto mimarco =new MaroconTexto();
	
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}


class MaroconTexto extends JFrame{

	public MaroconTexto() {
		
	setVisible(true);
	
	setSize(600,450);
	
	setLocation(400,200);
	
	setTitle("Prueba String");
	
	Lamina milamina =new Lamina();
	
	add(milamina);
	
	}
	
	
}


class Lamina extends JPanel{
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		g.drawString("Escribe tu nombre", 100, 100);
	}
}