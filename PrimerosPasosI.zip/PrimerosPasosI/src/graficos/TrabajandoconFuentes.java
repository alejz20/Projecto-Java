package graficos;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class TrabajandoconFuentes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MarcoconFuentes mimarco =new MarcoconFuentes();
		
		mimarco.setVisible(true);
	
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}



class MarcoconFuentes extends JFrame {

	public MarcoconFuentes() {
		
		setSize(400,400);

		setTitle("Pueba con fuentes");
		
		LaminaconFuentes milamina=new LaminaconFuentes();
		
		add(milamina); // IMPORTANTE --> MUESTRA MARCO
		
		//		milamina.setForeground(Color.BLUE);  PONE EL TEXTO DE UN SOLO COLOR

}
	
}


class LaminaconFuentes extends JPanel {
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);

		
		Graphics2D g2=(Graphics2D) g;
		
		Font mifuente=new Font("Arial", Font.BOLD,26);
		
		g2.setFont(mifuente);
		
		g2.setColor(Color.BLUE);
		
		g2.drawString("Patrick", 100, 100);
		
		g2.setFont(new Font("Verdana", Font.ITALIC,14));
				
		g2.setColor(Color.CYAN);
		
		g2.drawString("Curso Java", 100, 200);
		
	
		
		
			
		
	}

}
 
