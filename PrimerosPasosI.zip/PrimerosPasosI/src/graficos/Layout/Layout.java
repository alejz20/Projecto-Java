package graficos.Layout;
import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Layout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Marco_Layout marco =new Marco_Layout();
		
		marco.setVisible(true);
		
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}

}

class Marco_Layout extends JFrame {

	public Marco_Layout() {
		
		setSize(400,400);

		setTitle("Pueba Acciones");
		
		Panel_Layout lamina=new Panel_Layout();
		
		add(lamina); // IMPORTANTE --> MUESTRA MARCO
		
		Panel_Layout_II lamina2=new Panel_Layout_II();

		add(lamina, BorderLayout.NORTH);
		
		add(lamina2, BorderLayout.SOUTH);
}
	
}
class Panel_Layout extends JPanel{
	
	public Panel_Layout() {
		
		setLayout(new FlowLayout(FlowLayout.RIGHT));
		
		add(new JButton ("Amarillo"), BorderLayout.NORTH);
		
		add(new JButton ("Rojo"), BorderLayout.SOUTH);

		
		
	}
}

class Panel_Layout_II extends JPanel{
	
	
	
	public Panel_Layout_II() {
	
		setLayout(new BorderLayout());
		
		add(new JButton ("Azul"), BorderLayout.WEST);
		
		add(new JButton ("Verde"), BorderLayout.EAST);
		
		add(new JButton ("Negro"));
	}
	
}