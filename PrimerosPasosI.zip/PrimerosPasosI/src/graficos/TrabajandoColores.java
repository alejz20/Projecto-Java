package graficos;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.SystemColor;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class TrabajandoColores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		MarcoconColor mimarco =new MarcoconColor();
		
		mimarco.setVisible(true);
	
		mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	
	}

}


class MarcoconColor extends JFrame {

	public MarcoconColor() {
		
		setSize(400,400);

		setTitle("Pueba con colores");
		
		LaminaconColor milamina=new LaminaconColor();
		
		add(milamina); // IMPORTANTE --> MUESTRA MARCO
		
		//	milamina.setBackground(Color.CYAN);
		
		milamina.setBackground(SystemColor.window);

}
	
}


class LaminaconColor extends JPanel {
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		Graphics2D g2=(Graphics2D) g;
		
		// dibujo con rectangulo
		
		
		Rectangle2D rectangulo = new Rectangle2D.Double(100, 100, 200, 150);
		
		g2.setPaint(Color.BLUE);
		
		g2.draw(rectangulo);
		
		g2.setPaint(Color.GREEN);
		
		g2.fill(rectangulo);
		
		// dibujo elipse
		
		
		Ellipse2D elipse = new Ellipse2D.Double();
				
		elipse.setFrame(rectangulo);
		
		Color micolor= new Color(126,200,0);
		
//		g2.setPaint(new Color(157,140,255).darker().brighter());
		
		g2.setPaint(micolor);
		
		g2.fill(elipse);
	
			
		
			
		
	}

}
 
