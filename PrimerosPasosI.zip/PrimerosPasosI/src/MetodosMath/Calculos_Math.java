package MetodosMath;

public class Calculos_Math {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/* 
		 * Ejemplo de raiz
		 
		 Es, obligatorio, de tipo double
		 
		 */
		double raiz=Math.sqrt(9);
		
		System.out.println(raiz);
		
		/* 
		 * Ejemplo de redondeo
		 
		 El metodo round , devuelde 2 variables
		 
		 .Double
		 .float
		 */
		
		
		double num1=5.85;
		// Pero si queremos q nuestro programa nos devuelva un int, hacemos refundicion.
		
		int resultado=(int)Math.round(num1);
		
		System.out.println(resultado);
		
		/* 
		 * Ejemplo de potencia
		
		 */
	
		double base=5;
		
		double exponente=3;
		
		/* Refundicion de double a int  */
		int resultado1=(int) Math.pow(base, exponente);
		
		System.out.println("El resultado de " + base+ " elevado a " + exponente + " es " + resultado1);
		
	
		
	}

}
