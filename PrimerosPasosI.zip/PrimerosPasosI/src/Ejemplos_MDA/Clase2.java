package Ejemplos_MDA;

import Ejemplos_MDAII.Clase3;
public class Clase2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Clase1 miobj=new Clase1();
	
	Clase3 miobj2=new Clase3();
	
	//miobj
	
	}

}
