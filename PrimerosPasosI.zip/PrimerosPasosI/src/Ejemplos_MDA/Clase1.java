package Ejemplos_MDA;

public class Clase1 {

	protected 	int mivar = 6;
	protected int mivar2 =2;
	
	protected String mimetodo() {
		return "El valor de mivar2 es: " + mivar2;
	}

}
