package file_archivo;

import java.io.File;

/* Clase y metodos de la clase File *\*/
public class CyM {

    public static void main(String[] args) {
        File fichero = new File("C:\\Users\\madrid\\Desktop\\EJERCICIO1_CONTAR\\The Dunwhich horror by H.P Lovecraft");


        if (
                fichero.exists()
        ){

            System.out.println("Nombre del archivo "+fichero.getName());
            System.out.println("Camino             "+fichero.getPath());
            System.out.println("Camino absoluto    "+fichero.getAbsolutePath());
            System.out.println("Se puede escribir  "+fichero.canRead());
            System.out.println("Se puede leer      "+fichero.canWrite());
            System.out.println("Tamaño             "+fichero.length());

        }
    }


}
