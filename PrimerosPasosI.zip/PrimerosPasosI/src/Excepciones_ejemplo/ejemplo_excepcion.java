package Excepciones_ejemplo;

public class ejemplo_excepcion {

    public static void main(String[] args) {

        int edad [] = {15,34,54,43};
        try {
            System.out.println("La edad de la posición 4 es: " + edad[4]);
        }catch (Exception e){

            System.out.println("Intentaste imprimir una variable del array no existente");
        }
    }
}
