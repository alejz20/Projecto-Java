package MetodosString;

public class Manipula_cadenaII {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String alumno1, alumno2;
	
	alumno1="david";
	
	alumno2="David";
	
	System.out.println(alumno1.equals(alumno2));
	
	// equals, compara caracter o cadena de caracteres
	// devuelde un 'true' o 'false'
	// Es case sentitive, por eso existe equalsIgnorecase
	
	System.out.print(alumno1.equalsIgnoreCase(alumno2));
	}

}
