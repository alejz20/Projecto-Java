package MetodosString;
public class Manipula_caracteres {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// String no es un tipo primitivo. Estamos hablando de un objeto.
		// En este caso, es una cadena de caracteres.
		// Objeto --> String
		
		
		String nombre="Don Manuel";
		
		System.out.println( "Mi nombre es " + nombre);
		
		
		// length - nos devuelde cuantas letras hay
		System.out.println( "Mi nombre tiene " + nombre.length() + " letras ");
		
		//Nos devuelde un caracter en la posicion indica
		System.out.println( "La primera letra de " + nombre + " es la " + nombre.charAt(5));
		
		/* 
		 * System.out.println( "La primera letra de " + nombre + " es la " + nombre.charAt(4));
		 */
		
		int ultima_letra;
		
		ultima_letra=nombre.length();
		
		System.out.println("Y la ultima letra es " + nombre.charAt(ultima_letra-1));
		
		
		
		
		
		
		
		
	}

}
