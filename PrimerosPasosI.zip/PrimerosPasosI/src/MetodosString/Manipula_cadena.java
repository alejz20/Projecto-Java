package MetodosString;

public class Manipula_cadena {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String frase ="Hoy es un estupendo dia para cagar";
	
	
	// extrae o devuelve una cadena o cadenas de carateres
	// .subtring(primero_posicion-de-la-q-quiero-extraer,ultima-posicion-q-quiero-extraer )
	String frase_resumen =frase.substring(20,30) + " e irnos de parranda "  
			 + frase.substring(29,34);
	
	System.out.println(frase_resumen);
	
	
	
	}

}
