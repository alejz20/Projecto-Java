package Bucles;

import java.util.Scanner;

public class AdivinaNumero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/* Declaramos una variable, aleatorio, a la q es igual a una 
	 * refundicion para q nos salgo numeros enteros, osea sin decimales */

	int aleatorio=(int)(Math.random()*100);
	
	/* RANDOM, te devuelve numeros aleatorios
	 * 
	 * Adem�s q lo multiplique x 100	
	////System.out.println(Math.random()*100);////
	
	*/
			
	Scanner entrada=new Scanner(System.in);
	
	int numero=0;
	
	int intentos=0;
	/* 
	 * Es un operador, significa diferente.
	 * En este caso
	 * 
	 * numero!(numero diferente de )=aleatorio
	 */
	
	while(numero!=aleatorio) {
		intentos++;
		
			System.out.println("Introduce numero");
	
		numero=entrada.nextInt();
		
		if(aleatorio<numero) {
			
			System.out.println("Mas bajo");

		}
		
		else if(aleatorio>numero) {
			
			System.out.println("Mas alto");

		}
		
	}	
	System.out.println("Correcto. Lo has conseguido en " + intentos + " intentos");
	
	}
}
