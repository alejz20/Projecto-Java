package Bucles;

import javax.swing.JOptionPane;

public class Factorial_ejemplo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int resultado=1;
	
	int numero=Integer.parseInt(JOptionPane.showInputDialog("Introduce numero"));
					// i tiene q ser mayor q 0
	for(int i=numero;i>0;i--) {
		
		resultado=resultado*i;
	}
	
	System.out.println("El factorial de " + numero + " es " + resultado  );
	}

}
