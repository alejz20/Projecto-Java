package Bucles;
import javax.swing.JOptionPane;

public class PesoIdeal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* xHay 2 tipos de Bucles

		-Indeterminados, programa infinito
		-Determinados, sabemos cuanto se va a repetir


		*/

		String genero="";
			//Ejemplo de indeterminado, bucle do .... while
			do {
				
				genero=JOptionPane.showInputDialog("Introduce tu genero (H/M)");
				
			}while(genero.equalsIgnoreCase("H")==false && genero.equalsIgnoreCase("M")==false);
			
			int altura=Integer.parseInt(JOptionPane.showInputDialog("Introduce la altura en cm"));
			
			int pesoideal=0;
			
			if(genero.equalsIgnoreCase("H")) {
				
				pesoideal=altura-110;
			}
			
			else if (genero.equalsIgnoreCase("M")) {
				pesoideal=altura-120;
				
			}
			
			System.out.println("Tu peso ideal es " + pesoideal);
		}
	
	}



