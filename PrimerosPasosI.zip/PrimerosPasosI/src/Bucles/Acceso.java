package Bucles;

import javax.swing.JOptionPane;
public class Acceso {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String clave="Alex";
	
	String pass="";
	//Ejemplo de indeterminado, bucle while

	while (clave.equals(pass)==false) {
		
		pass=JOptionPane.showInputDialog("Introduce la contrase�a");
	
	
		/* Si es falso, te imprime el mensaje*/

	if (clave.equals(pass)==false) {
		
		System.out.println("Contrae�a incorrecta ");
		
		}
	}
		System.out.println("Contrae�a correcta. Acceso permitido ");
	
	
}
}
