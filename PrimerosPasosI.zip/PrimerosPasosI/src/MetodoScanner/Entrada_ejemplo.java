package MetodoScanner;
// importamos la clase Scanner a su paquete correspondiente
import java.util.Scanner;
public class Entrada_ejemplo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Este es un ejemplo de Scanner
		// Scanner es una clase en la que puede INtroducir en consola
		
		
		// Q implica q un metodo no sea estatico?
		//
		// Q tenemos q crearnos un objeto para usar el metodo.
		//
		// Y si fuera estatico?
		//
		// Implica q tengamos que poner la clase perteneciente con el metodo.
		// por ejemplo:
		//
		// JOptionPanel
		
	
		
		/* Scanner es un ejemplo de una clase no estatico, por lo que 
		 * creamos un objeto llamado entrada a la q declaramos como
		 * Scanner entrada*/
		
		Scanner entrada=new Scanner(System.in);
		
		System.out.println("Introduce tu nombre");
		
		/* nextLine, sirve par a hace salto de linea*/
		
		String nombre_usuario=entrada.nextLine();
		
		System.out.println("Introduce tu edad");
		
		/* Este metodo nos devuelve un dato de tipo int*/
		
		int edad=entrada.nextInt();
		
		System.out.println("Hola " + nombre_usuario + " El a�o q viene tendras " +(edad+1) + "a�os ");
	}

}
