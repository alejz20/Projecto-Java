package Enum;
import java.util.Scanner;
public class Uso_Tallas {

	//enum es una clase especial, que limita los objetos declarados.
	
	enum Talla{
		
		MINI("S"),MEDIANO("M"),GRANDE("L"),MUYGRANDE("XL");
		
		private String abreviatura;
		
	
		private Talla(String abreviatura) {
			
			this.abreviatura=abreviatura;
		}
		
		public String dameAbreviatura() {
			return abreviatura;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	
	Scanner s =new Scanner(System.in);
	
	System.out.println("Escribe una talla: MINI, MEDIANO, GRANDE, MUYGRANDE");
	
	String datos=s.next().toUpperCase(); // Te devuele los datos de la consola en MAYUSCULAS es como UPPER
	
	Talla la_talla=Enum.valueOf(Talla.class, datos); //devuelve las variables ENUM especificado antes.
	 
	System.out.println("Talla: " + la_talla);
	
	System.out.println("Abreviatura: " + la_talla.dameAbreviatura());
	
	}
}
