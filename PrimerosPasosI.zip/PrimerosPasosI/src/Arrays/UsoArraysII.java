package Arrays;

public class UsoArraysII {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String paises[]= {"Peru","Madrid","Segovia","Barcelona","Egipto","Chile","Mexico"};

		for(String elemento:paises) {
			
			System.out.println("Pais " + elemento);
		}
	}

}
