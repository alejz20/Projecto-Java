package Arrays;

public class UsoArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		int numeros[]=new int [5];
		
		numeros[0]=45;
		numeros[1]=345;
		numeros[2]=53;
		numeros[3]=24;
		numeros[4]=353;
		
		System.out.println(numeros[2]);
		System.out.println(numeros[0]);
		System.out.println(numeros);  --Resultado :'[I@626b2d4a' Error --
		*/
	
		int numeros[]= {24,6,63,6,3,-3,345,35,87,54,54};

		for(int i=0;i<numeros.length;i++) {
			
			System.out.println("NUmero: " +i+ " es " + numeros[i] );
		}
	}

}
