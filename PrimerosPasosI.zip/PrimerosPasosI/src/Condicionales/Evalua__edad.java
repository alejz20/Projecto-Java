package Condicionales;
import java.util.Scanner;
public class Evalua__edad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner entrada=new Scanner(System.in);
		
	System.out.println("Introduce tu edad");
	
	int edad=entrada.nextInt();
	

	/* Ejemplo 1 
	 * 
	 * 
	 *if(edad>5=18){
	
		System.out.println("Eres mayor de edad");
	}
	
	else{ 
		
		System.out.println("Eres menor de edad");
	 * 
		 * */
	
	 //EJEMPLO 2
		if(edad<=18){
	
			System.out.println("Eres un adolecente");
		}
	
		else if (edad<=40){ 
		
			System.out.println("Eres joven");
		
		 }
	
		else if (edad<=65){ 
		
			System.out.println("Eres maduro");
		}
		
		else { 
		
			System.out.println("Cuidate");
		
		 }
	
		
	}
	
	
	
	}


