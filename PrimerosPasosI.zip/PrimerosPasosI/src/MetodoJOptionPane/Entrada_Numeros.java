package MetodoJOptionPane;
import javax.swing.JOptionPane;

public class Entrada_Numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	double x=10000.0;
	
	/* printf, nos imprime con formato*/
		System.out.printf("%1.4f", x);
		//Resultado: 10000,0000
	System.out.printf("%1.4f", x/3);
		//Resultado: 3333,3333
	/* Modicamos los decimales.
	 * .printf(%1.elegimos-cuantos-decimales, formato-de-la-variable)
	 * 2 Hace referencia la cantidad de decimales que quieras
	 * */
	
	
	/* Ejemplo con raiz cuadrada*/
	
	String num1=JOptionPane.showInputDialog("Introduce un numero");
	
	/* Es como el integer.parseint, pero este te devuelde un double*/
	double num2=Double.parseDouble(num1);
	
	System.out.println(" La raiz de " + num2 + "es ");
	
	System.out.printf("%1.2f", Math.sqrt(num2));
	}

}
