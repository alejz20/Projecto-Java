package MetodoJOptionPane;
import javax.swing.JOptionPane;
public class Entrada_Ejemplo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String nombre_usuario=JOptionPane.showInputDialog("Introduce tu nombre");
	
	String edad=JOptionPane.showInputDialog("Introduce tu edad");
	
	System.out.println("Hola " + nombre_usuario + ". Tienes " + edad + " años. ");
	
	
	/* Al intentar imprimir esto te saldra un tipo string.
	 Por ejemplo.
	Introducimos en edad 20
	En la consola aparece . El a�o que vienes tendras 201 a�os.
	Para corregir esto usamos METODO ParseInt
    Convierte un numero entero a un string.
    Es estatico. Por eso se escribe Integre.parseInt

    */
    
    	int edad_usuario=Integer.parseInt(edad);
    	
	System.out.println("Hola " + nombre_usuario + ". El a�o que viene tendras " + (edad+1) + " a�os. ");


	
	

	
	
	
	}

}
